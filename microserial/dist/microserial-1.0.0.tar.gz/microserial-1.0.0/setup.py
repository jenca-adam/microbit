from setuptools import setup
setup(
    name='microserial',
    version='1.0.0',
    install_requires=['pyserial'],
    author="Adam Jenca",
    author_email='jenca.a@gjh.sk',
    url="about:blank",
)
